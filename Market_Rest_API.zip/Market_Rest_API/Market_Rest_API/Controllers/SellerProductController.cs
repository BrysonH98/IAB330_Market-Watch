﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MySql.Data.MySqlClient;
using Market_Rest_API.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace Market_Rest_API.Controllers
{
    public class SellerProductController : ApiController
    {

        MySqlConnection conn = new MySqlConnection("Database=mw_db;Data Source=marketwatchserver.mysql.database.azure.com;User Id=mw3944176B06F@marketwatchserver;Password=522E3E39F695B75AC94EE05F43084971D4EA2B99!?");

        private int sellerProductID = 0;
        private int sellerID = 0;
        private int productID = 0;

        [HttpGet]
        [Route("api/SellerProduct")]
        public List<SellerProduct> Get()
        {
            List<SellerProduct> SellerProduct = new List<SellerProduct>();
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM SellerProduct");
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                SellerProduct.Add(new SellerProduct
                {
                    sellerProductID = (int)reader["sellerProductID"],
                    sellerID = (int)reader["sellerID"],
                    productID = (int)reader["productID"],
                });


            }
            reader.Close();

            return SellerProduct;

        }


        // GET api/values/5
        [HttpGet]
        [Route("api/SellerProduct/{id}")]
        public SellerProduct Get(int id)
        {

            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM SellerProduct WHERE sellerProductID = {0}", id);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                sellerProductID = (int)reader["sellerProductID"];
                sellerID = (int)reader["sellerID"];
                productID = (int)reader["productID"];
            }
            reader.Close();

            return new SellerProduct
            {
                sellerProductID = sellerProductID,
                sellerID = sellerID,
                productID = productID
            };
        }

        // POST api/values
        [HttpPost]
        [Route("api/SellerProduct/sID={selID}/pID={prdID}")]
        public void Post(int selID, int prdID)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = "INSERT INTO SellerProduct(sellerId, productID) VALUES(?sellerID, ?productID)";

            comm.Parameters.Add("?sellerID", MySqlDbType.Int32).Value = selID;
            comm.Parameters.Add("?productID", MySqlDbType.Int32).Value = prdID;


            comm.ExecuteNonQuery();
            conn.Close();
        }

        // PUT api/values/5
        /*
        public void Put(int id, [FromBody]SellerProduct sellerProduct)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("UPDATE SellerProduct SET selPassword = {0} WHERE SellerProductID = {1}", SellerProduct.selPassword, id);

            comm.ExecuteNonQuery();
            conn.Close();
        }*/

        // DELETE api/values/5
        [HttpDelete]
        [Route("api/SellerProduct/{id}")]
        public bool Delete(int id)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("DELETE FROM SellerProduct WHERE SellerProductID = {0}", id);

            int status = comm.ExecuteNonQuery();

            conn.Close();
            return (status > 1) ? true : false;
        }
    }
}
