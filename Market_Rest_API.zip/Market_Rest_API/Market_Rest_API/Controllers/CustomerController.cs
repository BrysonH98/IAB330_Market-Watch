﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MySql.Data.MySqlClient;
using Market_Rest_API.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace Market_Rest_API.Controllers
{
    public class CustomerController : ApiController
    {

        MySqlConnection conn = new MySqlConnection("Database=mw_db;Data Source=marketwatchserver.mysql.database.azure.com;User Id=mw3944176B06F@marketwatchserver;Password=522E3E39F695B75AC94EE05F43084971D4EA2B99!?");

        private int customerID = 0;
        private string email = "placeholder";
        private string cusPassword = "placeholder";
        private int phone = 01234123414;

        public IEnumerable<Customer> Get()
        {
            List<Customer> customer = new List<Customer>();
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Customer");
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                customerID = (int)reader["customerID"];
                email = (string)reader["email"];
                cusPassword = (string)reader["cusPassword"];
                phone = (int)reader["phone"];

                customer.Add(new Customer
                {
                    customerID = customerID,
                    email = email,
                    cusPassword = cusPassword,
                    phone = phone,
                });


            }
            reader.Close();

            return customer;

        }


        // GET api/customer/5
        public Customer Get(int id)
        {

            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Customer WHERE customerID = {0}", id);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                customerID = (int)reader["customerID"];
                email = (string)reader["email"];
                cusPassword = (string)reader["cusPassword"];
                phone = (int)reader["phone"];
            }
            reader.Close();

            return new Customer
            {
                customerID = customerID,
                email = email,
                cusPassword = cusPassword,
                phone = phone
            };
        }


        public Customer Get(string email, string password)
        {
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Customer WHERE email = {0} AND password = {1}", email, password);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                customerID = (int)reader["customerID"];
                email = (string)reader["email"];
                cusPassword = (string)reader["cusPassword"];
                phone = (int)reader["phone"];


            }
            reader.Close();

            return new Customer
            {
                customerID = customerID,
                email = email,
                cusPassword = cusPassword,
                phone = phone,
            };

        }

        // POST api/customer
        [HttpPost]
        [Route("api/Customer")]
        public void Post([FromBody] Customer customer)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = "INSERT INTO Customer(email, cusPassword, phone) customer(?email, ?cusPassword, ?phone)";

            comm.Parameters.Add("?email", MySqlDbType.VarChar).Value = customer.email;
            comm.Parameters.Add("?cusPassword", MySqlDbType.VarChar).Value = customer.cusPassword;
            comm.Parameters.Add("?phone", MySqlDbType.VarChar).Value = customer.phone;


            comm.ExecuteNonQuery();
            conn.Close();
        }

        // PUT api/customer/5
        public void Put(int id, [FromBody]Customer customer)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("UPDATE Customer SET cusPassword = {0} WHERE customerID = {1}", customer.cusPassword, id);

            comm.ExecuteNonQuery();
            conn.Close();
        }

        // DELETE api/customer/5
        public bool Delete(int id)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("DELETE FROM Customer WHERE customerID = {0}", id);

            comm.ExecuteNonQuery();
            conn.Close();

            return true;
        }
    }
}
