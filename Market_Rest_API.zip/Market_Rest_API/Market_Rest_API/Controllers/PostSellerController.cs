﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MySql.Data.MySqlClient;
using Market_Rest_API.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace Market_Rest_API.Controllers
{
    public class PostSellerController : ApiController
    {

        MySqlConnection conn = new MySqlConnection("Database=mw_db;Data Source=marketwatchserver.mysql.database.azure.com;User Id=mw3944176B06F@marketwatchserver;Password=522E3E39F695B75AC94EE05F43084971D4EA2B99!?");

        private int postSellerID;
        private int postID;
        private int sellerID;

        [HttpGet]
        [Route("api/PostSeller")]
        public List<PostSeller> Get()
        {
            List<PostSeller> postSeller = new List<PostSeller>();
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM PostSeller");
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                postSeller.Add(new PostSeller
                {
                    postSellerID = (int)reader["postSellerID"],
                    postID = (int)reader["postID"],
                    sellerID = (int)reader["sellerID"],
                });


            }
            reader.Close();

            return postSeller;

        }


        // GET api/values/5
        [HttpGet]
        [Route("api/PostSeller/{id}")]
        public PostSeller Get(int id)
        {

            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM PostSeller WHERE postpostID = {0}", id);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                postSellerID = (int)reader["postSellerID"];
                postID = (int)reader["postID"];
                sellerID = (int)reader["sellerID"];
            }
            reader.Close();

            return new PostSeller
            {
                postSellerID = postSellerID,
                postID = postID,
                sellerID = sellerID
            };
        }

        // POST api/values
        [HttpPost]
        [Route("api/PostSeller/pID={posID}/sID={selID}")]
        public void Post(int posID, int selID)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = "INSERT INTO PostSeller(postID, sellerID) VALUES(?postID, ?sellerID)";

            comm.Parameters.Add("?postID", MySqlDbType.Int32).Value = posID;
            comm.Parameters.Add("?sellerID", MySqlDbType.Int32).Value = selID;


            comm.ExecuteNonQuery();
            conn.Close();
        }

        // PUT api/values/5
        /*
        public void Put(int id, [FromBody]PostSeller PostSeller)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("UPDATE PostSeller SET selPassword = {0} WHERE postpostID = {1}", PostSeller.selPassword, id);

            comm.ExecuteNonQuery();
            conn.Close();
        }*/

        // DELETE api/values/5
        [HttpDelete]
        [Route("api/PostSeller/{id}")]
        public bool Delete(int id)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("DELETE FROM PostSeller WHERE postSellerID = {0}", id);

            int status = comm.ExecuteNonQuery();

            conn.Close();
            return (status > 1) ? true : false;
        }
    }
}
