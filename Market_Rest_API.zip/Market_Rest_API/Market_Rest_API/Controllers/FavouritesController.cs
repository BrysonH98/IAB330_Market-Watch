﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MySql.Data.MySqlClient;
using Market_Rest_API.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace Market_Rest_API.Controllers
{
    public class FavouritesController : ApiController
    {

        MySqlConnection conn = new MySqlConnection("Database=mw_db;Data Source=marketwatchserver.mysql.database.azure.com;User Id=mw3944176B06F@marketwatchserver;Password=522E3E39F695B75AC94EE05F43084971D4EA2B99!?");

        private int favouriteID = 0;
        private int customerID = 0;
        private int sellerID = 0;

        public IEnumerable<Favourites> Get()
        {
            List<Favourites> favourites = new List<Favourites>();
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Favourites");
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                favouriteID = (int)reader["favouriteID"];
                customerID = (int)reader["customerID"];
                sellerID = (int)reader["sellerID"];

                favourites.Add(new Favourites
                {
                    favouriteID = favouriteID,
                    sellerID = sellerID,
                    customerID = customerID
                });


            }
            reader.Close();

            return favourites;

        }


        // GET api/Favourites/5
        public Favourites Get(int id)
        {

            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Favourites WHERE favouriteID = {0}", id);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                favouriteID = (int)reader["favouriteID"];
                customerID = (int)reader["customerID"];
                sellerID = (int)reader["sellerID"];
            }
            reader.Close();

            return new Favourites
            {
                favouriteID = favouriteID,
                sellerID = sellerID,
                customerID = customerID 
            };
        }

        // POST api/Favourites
        [HttpPost]
        [Route("api/Favourites")]
        public void Post([FromBody] Favourites favourites)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = "INSERT INTO Favourites Favourites(?favouriteID, ?customerID, ?sellerID)";

            comm.Parameters.Add("?favouriteID", MySqlDbType.Int32).Value = favourites.favouriteID;
            comm.Parameters.Add("?customerID", MySqlDbType.Int32).Value = favourites.customerID;
            comm.Parameters.Add("sellerID", MySqlDbType.Int32).Value = favourites.sellerID;


            comm.ExecuteNonQuery();
            conn.Close();
        }

        // PUT api/Favourites/5
        /*
        public void Put(int id, [FromBody]Favourites favourites)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("UPDATE Favourites SET cusPassword = {0} WHERE favouriteID = {1}", favourites.cusPassword, id);

            comm.ExecuteNonQuery();
            conn.Close();
        }*/

        // DELETE api/Favourites/5
        public bool Delete(int id)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("DELETE FROM Favourites WHERE favouriteID = {0}", id);

            comm.ExecuteNonQuery();
            conn.Close();

            return true;
        }
    }
}
