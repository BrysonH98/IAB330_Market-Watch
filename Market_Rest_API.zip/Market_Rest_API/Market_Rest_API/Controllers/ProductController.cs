﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MySql.Data.MySqlClient;
using Market_Rest_API.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace Market_Rest_API.Controllers
{
    public class ProductController : ApiController
    {

        MySqlConnection conn = new MySqlConnection("Database=mw_db;Data Source=marketwatchserver.mysql.database.azure.com;User Id=mw3944176B06F@marketwatchserver;Password=522E3E39F695B75AC94EE05F43084971D4EA2B99!?");

        private int productID = 0;
        private string prdName = "placeholder";
        private float price = 17.00f;
        private string picture = "placeholder";
        private string description = "placeholder";

        public IEnumerable<Product> Get()
        {
            List<Product> product = new List<Product>();
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Product");
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                productID = (int)reader["productID"];
                prdName = (string)reader["prdName"];
                price = (float)reader["price"];
                picture = (string)reader["picture"];
                description = (string)reader["description"];

               product.Add(new Product
                {
                    productID = productID,
                    prdName = prdName,
                    price = price,
                    picture = picture,
                    description = description
                });


            }
            reader.Close();

            return Product;

        }


        // GET api/Product/5
        public Product Get(int id)
        {

            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Product WHERE productID = {0}", id);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                productID = (int)reader["productID"];
                prdName = (string)reader["prdName"];
                price = (float)reader["price"];
                picture = (string)reader["picture"];
                description = (string)reader["description"];
            }
            reader.Close();

            return new Product
            {
                productID = productID,
                prdName = prdName,
                price = price,
                picture = picture,
                description = description
            };
        }

        // POST api/Product
        [HttpPost]
        [Route("api/Product")]
        public void Post([FromBody] Product product)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = "INSERT INTO Product(prdName, price, picture, description) Product(?prdName, ?price, ?picture, ?description)";

            comm.Parameters.Add("?prdName", MySqlDbType.VarChar).Value = product.prdName;
            comm.Parameters.Add("?price", MySqlDbType.VarChar).Value = product.price;
            comm.Parameters.Add("?picture", MySqlDbType.VarChar).Value = product.picture;
            comm.Parameters.Add("?description", MySqlDbType.VarChar).Value = product.description;


            comm.ExecuteNonQuery();
            conn.Close();
        }

        // PUT api/Product/5
        /*
        public void Put(int id, [FromBody]Product product)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("UPDATE Product SET cusPassword = {0} WHERE productID = {1}", product.cusPassword, id);

            comm.ExecuteNonQuery();
            conn.Close();
        }*/

        // DELETE api/Product/5
        public bool Delete(int id)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("DELETE FROM Product WHERE productID = {0}", id);

            comm.ExecuteNonQuery();
            conn.Close();

            return true;
        }
    }
}
