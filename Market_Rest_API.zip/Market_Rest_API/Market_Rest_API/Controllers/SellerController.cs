﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MySql.Data.MySqlClient;
using Market_Rest_API.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace Market_Rest_API.Controllers
{
    public class SellerController : ApiController
    {

        MySqlConnection conn = new MySqlConnection("Database=mw_db;Data Source=marketwatchserver.mysql.database.azure.com;User Id=mw3944176B06F@marketwatchserver;Password=522E3E39F695B75AC94EE05F43084971D4EA2B99!?");

        private int sellerID;
        private string businessName;
        private string email;
        private string selPassword;
        private int phone;
        private string location;

        /// <summary>
        /// Responds to a get command when an id number isn't provided and gets all sellers in the database. The uri route of which is api/seller
        /// </summary>
        /// <returns>A list of all sellers in the database</returns>
        [HttpGet]
        [Route("api/Seller")]
        public List<Seller> Get()
        {
            List<Seller> seller = new List<Seller>();
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Seller");
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                sellerID = (int)reader["sellerID"];
                businessName = (string)reader["businessName"];
                email = (string)reader["email"];
                selPassword = (string)reader["selPassword"];
                phone = (int)reader["phone"];
                location = (string)reader["location"];

                seller.Add(new Seller
                {
                    sellerID = sellerID,
                    businessName = businessName,
                    email = email,
                    selPassword = selPassword,
                    phone = phone,
                    location = location
                });


            }
            reader.Close();

            return seller;

        }

        /// <summary>
        /// Responds to a get command and gets the seller associated with the ID. The uri route of which is api/seller/{id}
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/Seller/{id}")]
        public Seller Get(int id)
        {

            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Seller WHERE sellerID = {0}", id);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                sellerID = (int)reader["sellerID"];
                businessName = (string)reader["businessName"];
                email = (string)reader["email"];
                selPassword = (string)reader["selPassword"];
                phone = (int)reader["phone"];
                location = (string)reader["location"];

                
            }
            reader.Close();

            return new Seller
            {
                sellerID = sellerID,
                businessName = businessName,
                email = email,
                selPassword = selPassword,
                phone = phone,
                location = location
            };
        }


        /// <summary>
        /// Responds to a get request and gets the seller associated with the given email and password. The URI extension is /api/Seller/email={string}/password={string}
        /// </summary>
        /// <param name="email">The email of the Seller</param>
        /// <param name="password">The password of the Seller</param>
        /// <returns>The seller associated with the password and email</returns>
        [HttpGet]
        [Route("api/Seller/email={email}/selPassword={password}")]
        public Seller Get(string email, string password)
        {
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Seller WHERE email = '{0}' AND selPassword = '{1}'", email, password);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                sellerID = (int)reader["sellerID"];
                businessName = (string)reader["businessName"];
                email = (string)reader["email"];
                selPassword = (string)reader["selPassword"];
                phone = (int)reader["phone"];
                location = (string)reader["location"];


            }
            reader.Close();

            return new Seller
            {
                sellerID = sellerID,
                businessName = businessName,
                email = email,
                selPassword = selPassword,
                phone = phone,
                location = location
            };

        }

        /// <summary>
        /// Receives data in JSON format from a post request and adds it to the database. The URI extension for this api/Seller
        /// </summary>
        /// <param name="seller">The JSON object to be added to the database</param>
        [HttpPost]
        [Route("api/Seller")]
        public void Post([FromBody] Seller seller)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = "INSERT INTO Seller(businessName, email, selPassword, phone, location) VALUES(?businessName, ?email, ?selPassword, ?phone, ?location)";

            comm.Parameters.Add("?businessName", MySqlDbType.VarChar).Value = seller.businessName;
            comm.Parameters.Add("?email", MySqlDbType.VarChar).Value = seller.email;
            comm.Parameters.Add("?selPassword", MySqlDbType.VarChar).Value = seller.selPassword;
            comm.Parameters.Add("?phone", MySqlDbType.Int32).Value = seller.phone;
            comm.Parameters.Add("?location", MySqlDbType.VarChar).Value = seller.location;


            comm.ExecuteNonQuery();
            conn.Close();
        }

        /// <summary>
        /// Recieves information from a PUT request and updates the database appropriatly. The URI extension for this is api/Seller/{id}
        /// </summary>
        /// <param name="id">The id of the seller</param>
        /// <param name="seller">The information that needs to be changed</param>
        [HttpPut]
        [Route("api/Seller")]
        public void Put(int id, [FromBody]Seller seller)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("UPDATE Seller SET selPassword = {0} WHERE sellerID = {1}", seller.selPassword, id);

            comm.ExecuteNonQuery();
            conn.Close();
        }

        /// <summary>
        /// Deletes the object at the given id number in the database. The URI extension is api/values/{id}
        /// </summary>
        /// <param name="id">The id of the seller that needs to be deleted</param>
        /// <returns>True if the operation was a success or false if it failed</returns>
        [HttpDelete]
        [Route("api/Seller")]
        public bool Delete(int id)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("DELETE FROM Seller WHERE sellerID = {0}", id);

            int status = comm.ExecuteNonQuery();

            conn.Close();
            return (status > 1) ? true : false;
        }
    }
}
