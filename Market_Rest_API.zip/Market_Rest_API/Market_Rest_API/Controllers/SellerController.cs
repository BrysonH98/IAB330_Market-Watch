﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MySql.Data.MySqlClient;
using Market_Rest_API.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace Market_Rest_API.Controllers
{
    public class SellerController : ApiController
    {

        MySqlConnection conn = new MySqlConnection("Database=mw_db;Data Source=marketwatchserver.mysql.database.azure.com;User Id=mw3944176B06F@marketwatchserver;Password=522E3E39F695B75AC94EE05F43084971D4EA2B99!?");

        private int sellerID = 0;
        private string businessName = "placeholder";
        private string email = "placeholder";
        private string selPassword = "placeholder";
        private int phone = 01234123414;
        private string location = "placeholder";

        public IEnumerable<Seller> Get()
        {
            List<Seller> seller = new List<Seller>();
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Seller");
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                sellerID = (int)reader["sellerID"];
                businessName = (string)reader["businessName"];
                email = (string)reader["email"];
                selPassword = (string)reader["selPassword"];
                phone = (int)reader["phone"];
                location = (string)reader["location"];

                seller.Add(new Seller
                {
                    sellerID = sellerID,
                    businessName = businessName,
                    email = email,
                    selPassword = selPassword,
                    phone = phone,
                    location = location
                });


            }
            reader.Close();

            return seller;

        }
        

        // GET api/values/5
        public Seller Get(int id)
        {

            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Seller WHERE sellerID = {0}", id);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                sellerID = (int)reader["sellerID"];
                businessName = (string)reader["businessName"];
                email = (string)reader["email"];
                selPassword = (string)reader["selPassword"];
                phone = (int)reader["phone"];
                location = (string)reader["location"];

                
            }
            reader.Close();

            return new Seller
            {
                sellerID = sellerID,
                businessName = businessName,
                email = email,
                selPassword = selPassword,
                phone = phone,
                location = location
            };
        }

        /*
        public Seller Get(string email, string password)
        {
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Seller WHERE email = {0} AND password = {1}", email, password);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                sellerID = (int)reader["sellerID"];
                businessName = (string)reader["businessName"];
                email = (string)reader["email"];
                selPassword = (string)reader["selPassword"];
                phone = (int)reader["phone"];
                location = (string)reader["location"];


            }
            reader.Close();

            return new Seller
            {
                sellerID = sellerID,
                businessName = businessName,
                email = email,
                selPassword = selPassword,
                phone = phone,
                location = location
            };

        }
        */

        // POST api/values
        [HttpPost]
        [Route("api/Seller")]
        public void Post([FromBody] Seller seller)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = "INSERT INTO Seller(businessName, email, selPassword, phone, location) VALUES(?businessName, ?email, ?selPassword, ?phone, ?location)";

            comm.Parameters.Add("?businessName", MySqlDbType.VarChar).Value = seller.businessName;
            comm.Parameters.Add("?email", MySqlDbType.VarChar).Value = seller.email;
            comm.Parameters.Add("?selPassword", MySqlDbType.VarChar).Value = seller.selPassword;
            comm.Parameters.Add("?phone", MySqlDbType.VarChar).Value = seller.phone;
            comm.Parameters.Add("?location", MySqlDbType.VarChar).Value = seller.location;


            comm.ExecuteNonQuery();
            conn.Close();
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]Seller seller)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("UPDATE Seller SET selPassword = {0} WHERE sellerID = {1}", seller.selPassword, id);

            comm.ExecuteNonQuery();
            conn.Close();
        }

        // DELETE api/values/5
        public bool Delete(int id)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("DELETE FROM Seller WHERE sellerID = {0}", id);

            comm.ExecuteNonQuery();
            conn.Close();

            return true;
        }
    }
}
