﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MySql.Data.MySqlClient;
using Market_Rest_API.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace Market_Rest_API.Controllers
{
    public class SearchController : ApiController
    {

        MySqlConnection conn = new MySqlConnection("Database=mw_db;Data Source=marketwatchserver.mysql.database.azure.com;User Id=mw3944176B06F@marketwatchserver;Password=522E3E39F695B75AC94EE05F43084971D4EA2B99!?");

        private int searchID = 0;
        private int sellerID = 0;
        private int customerID = 0;


        public IEnumerable<Search> Get()
        {
            List<Search> Search = new List<Search>();
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Search");
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Search.Add(new Search
                {
                    searchID = (int)reader["SearchID"],
                    sellerID = (int)reader["sellerID"],
                    customerID = (int)reader["customerID"],
                });


            }
            reader.Close();

            return Search;

        }


        // GET api/values/5
        public Search Get(int id)
        {

            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Search WHERE SearchID = {0}", id);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                searchID = (int)reader["SearchID"];
                sellerID = (int)reader["sellerID"];
                customerID = (int)reader["customerID"];
            }
            reader.Close();

            return new Search
            {
                searchID = searchID,
                sellerID = sellerID,
                customerID = customerID
            };
        }

        // POST api/values
        [HttpPost]
        [Route("api/Search")]
        public void Post([FromBody] Search search)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = "INSERT INTO Search VALUES(?SearchID, ?sellerID, ?customerID)";

            comm.Parameters.Add("?SearchID", MySqlDbType.Int32).Value = search.searchID;
            comm.Parameters.Add("?sellerID", MySqlDbType.Int32).Value = search.sellerID;
            comm.Parameters.Add("?customerID", MySqlDbType.Int32).Value = search.customerID;


            comm.ExecuteNonQuery();
            conn.Close();
        }

        // PUT api/values/5
        /*
        public void Put(int id, [FromBody]Search Search)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("UPDATE Search SET selPassword = {0} WHERE SearchID = {1}", Search.selPassword, id);

            comm.ExecuteNonQuery();
            conn.Close();
        }*/

        // DELETE api/values/5
        public bool Delete(int id)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("DELETE FROM Search WHERE SearchID = {0}", id);

            comm.ExecuteNonQuery();
            conn.Close();

            return true;
        }
    }
}
