﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MySql.Data.MySqlClient;
using Market_Rest_API.Models;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;

namespace Market_Rest_API.Controllers
{
    public class PostController : ApiController
    {

        MySqlConnection conn = new MySqlConnection("Database=mw_db;Data Source=marketwatchserver.mysql.database.azure.com;User Id=mw3944176B06F@marketwatchserver;Password=522E3E39F695B75AC94EE05F43084971D4EA2B99!?");

        private int postID;
        private string description;
        private string image;

        [HttpGet]
        [Route("api/Post/{id}")]
        public List<Post> Get(int id)
        {
            List<Post> post = new List<Post>();
            conn.Open();

            MySqlCommand command = conn.CreateCommand();
            command.CommandText = string.Format("SELECT * FROM Post NATURAL JOIN PostSeller WHERE PostSeller.sellerID = {0}; ", id);
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                postID = (int)reader["postID"];
                description = (string)reader["description"];
                image = (string)reader["image"];

                post.Add(new Post
                {
                    postID = postID,
                    description = description,
                    image = image
                });


            }
            reader.Close();

            return post;

        }

        // POST api/Post
        [HttpPost]
        [Route("api/Post")]
        public void Post([FromBody] Post post)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = "INSERT INTO Post(description, image) Post(?description, ?image)";
            
            comm.Parameters.Add("?description", MySqlDbType.VarChar).Value = post.description;
            comm.Parameters.Add("image", MySqlDbType.VarChar).Value = post.image;


            comm.ExecuteNonQuery();
            conn.Close();
        }

        // PUT api/Post/5
        [HttpPut]
        [Route("api/Post/{id}")]
        public void Put(int id, [FromBody]string post)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("UPDATE Post SET description = {0} WHERE postID = {1}", post, id);

            comm.ExecuteNonQuery();
            conn.Close();
        }

        // DELETE api/Post/5
        [HttpDelete]
        [Route("api/Post/{id}")]
        public bool Delete(int id)
        {
            conn.Open();

            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = string.Format("DELETE FROM Post WHERE postID = {0}", id);

            int status = comm.ExecuteNonQuery();

            conn.Close();
            return (status > 1) ? true : false;
        }
    }
}
