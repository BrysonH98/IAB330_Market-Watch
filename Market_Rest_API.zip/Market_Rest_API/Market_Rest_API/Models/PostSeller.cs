﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Market_Rest_API.Models
{
    public class PostSeller
    {
        public int postSellerID { get; set; }
        public int postID { get; set; }
        public int sellerID { get; set; }
    }
}