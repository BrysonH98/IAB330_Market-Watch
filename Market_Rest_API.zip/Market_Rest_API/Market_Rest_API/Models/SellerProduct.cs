﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Market_Rest_API.Models
{
    public class SellerProduct
    {
        public int sellerProductID { get; set; }
        public int sellerID { get; set; }
        public int productID { get; set; }
    }
}