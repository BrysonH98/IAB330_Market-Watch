﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Market_Rest_API.Models
{
    public class Favourites
    {
        public int favouriteID { get; set; }
        public int customerID { get; set; }
        public int sellerID { get; set; }
    }
}