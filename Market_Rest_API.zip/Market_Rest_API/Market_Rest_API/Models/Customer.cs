﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Market_Rest_API.Models
{
    public class Customer
    {
        public int customerID { get; set; }
        public string email { get; set; }
        public string cusPassword { get; set; }
        public int phone { get; set; }
    }
}