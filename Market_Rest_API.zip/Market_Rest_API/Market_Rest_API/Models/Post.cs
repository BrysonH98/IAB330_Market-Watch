﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Market_Rest_API.Models
{
    public class Post
    {
        public int postID { get; set; }
        public string description { get; set; }
        public string image { get; set; }
    }
}