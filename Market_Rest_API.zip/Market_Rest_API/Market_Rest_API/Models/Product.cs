﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Market_Rest_API.Models
{
    public class Product
    {
        public int productID { get; set; }
        public string prdName { get; set; }
        public float price { get; set; }
        public string picture { get; set; }
        public string description { get; set; }
    }
}