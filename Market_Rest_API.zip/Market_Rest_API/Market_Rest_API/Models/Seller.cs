﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Market_Rest_API.Models
{
    public class Seller
    {
        public int sellerID { get; set; }
        public string businessName { get; set; }
        public string email { get; set; }
        public string selPassword { get; set; }
        public int phone { get; set; }
        public string location { get; set; }
    }
}