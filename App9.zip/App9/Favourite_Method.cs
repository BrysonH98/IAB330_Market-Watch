﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using RestSharp;
using RestSharp.Deserializers;

namespace App9
{
    public class Favourite_Method
    {
        public List<Favourite_Model> Favourite_List { get; set; }
        public Favourite_Model One_Favourite { get; set; }

        public Favourite_Method()
        {
            string uri = "/api/Seller/cusID=2/fav=true";

            var client = new RestClient("http://marketwatchapi.azurewebsites.net");
            var request = new RestRequest(uri, Method.GET);
            var response = client.Execute(request);

            RestSharp.Deserializers.JsonDeserializer deserial = new JsonDeserializer();


            if (response.StatusCode == HttpStatusCode.OK)
            {
                string rawResponse = response.Content;
                
                List<Favourite_Model> json_response = deserial.Deserialize<List<Favourite_Model>>(response);
                Favourite_List = json_response;
                
              

            }
        }
    }
}
