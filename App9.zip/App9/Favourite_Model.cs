﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App9
{
    public class Favourite_Model
    {
        public int sellerID { get; set; }
        public string businessName { get; set; }
        public string email { get; set; }
        public string selPassword { get; set; }
        public int phone { get; set; }
        public string location { get; set; }
    }
    public class Favourite_List
    {
        public List<Favourite_Model> Fav_List { get; set; }
    }
}
