﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Market_NoTab.Objects
{
    public class User
    {
        public int customerID { get; set; }
        public string email { get; set; }
        public string cusPassword { get; set; }
        public int phone { get; set; }
    }
}
