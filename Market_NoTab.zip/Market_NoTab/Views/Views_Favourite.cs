﻿using System;
using System.Collections.Generic;
using System.Text;
using Market_NoTab.Functions;
using Market_NoTab.Pages;

namespace Market_NoTab.Views
{
    public class Views_Favourite : Base_View
    {
       public Views_Favourite()
        {

            Title = "Favourites";
            var Favourite_Result = new Get_Favourites(2); 
            List_Of_Fav = Favourite_Result.Favourite_List;
        }
    }
}
