﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Threading.Tasks;
using Refit;

namespace Non_tabbed_Login
{
    public class Login_Method
    {
        public Login_Result Result { get; set; }
        public string Input_Email { get; set; }
        public string Input_Password { get; set; }

        public Login_Method( string inEmail, string inPass)
        {
            Input_Email = inEmail;
            Input_Password = inPass;

#pragma warning disable CS4014
            DownloadUserData();
        }


        async Task DownloadUserData()
        {
            var Phone_API = RestService.For<IPhoneAPI>("http://marketwatchapi.azurewebsites.net");
            Result = await Phone_API.GetLogin(Input_Email, Input_Password);
        }

        
    }
}
