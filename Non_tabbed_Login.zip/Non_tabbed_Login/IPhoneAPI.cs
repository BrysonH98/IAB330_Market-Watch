﻿using System;
using System.Threading.Tasks;
using Refit;

namespace Non_tabbed_Login
{
    public interface IPhoneAPI
    {
        [Get("/api/Customer/email={email}/cusPassword={password}")]
        Task<Login_Result> GetLogin(string email,string password);
    }
}