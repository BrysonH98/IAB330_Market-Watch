﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace App2
{
    public partial class CityListPage : ContentPage
    {
        public CityListPage()
        {
            InitializeComponent();

            BindingContext = new CityListViewModel();
        }

        async void Handle_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            var viewCityViewModel = new ViewCityViewModel((CityListItem)e.Item);
            await Navigation.PushAsync(new ViewCityPage() {
                BindingContext = viewCityViewModel
            });
        }
    }
}
