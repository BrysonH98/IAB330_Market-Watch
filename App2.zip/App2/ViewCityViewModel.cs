﻿using System;
using System.ComponentModel;
using System.Threading.Tasks;
using Refit;

namespace App2
{
    public class ViewCityViewModel : INotifyPropertyChanged
    {
        public CityListItem CityInfo { get; set; }
        public WeatherResult WeatherResult { get; set; }

        public ViewCityViewModel( CityListItem cityInfo)
        {
            CityInfo = cityInfo;

#pragma warning disable CS4014
            DownloadWeatherData();

        }

        public event PropertyChangedEventHandler PropertyChanged;

        async Task DownloadWeatherData()
        {
            var weatherAPI = RestService.For<IWeatherAPI>("http://api.openweathermap.org");
            WeatherResult = await weatherAPI.GetWeather(CityInfo.CityName);

            PropertyChanged(this, new PropertyChangedEventArgs(nameof(WeatherResult)));
        }
    }
}
