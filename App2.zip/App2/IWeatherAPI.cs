﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Refit;

namespace App2
{
    public interface IWeatherAPI
    {
        [Get("/data/2.5/weather?q={city}&APPID=12146bbb2a10897948a7df9d8157127d")]
        Task<WeatherResult> GetWeather(string city);
    }
}
