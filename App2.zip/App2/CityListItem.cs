﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App2
{
    public class CityListItem
    {
        public string ImagePath { get; set; }
        public string CityName { get; set; }
    }
}
