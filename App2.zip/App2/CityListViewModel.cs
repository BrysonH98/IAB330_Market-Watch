﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App2
{
    public class CityListViewModel
    {
        public List<CityListItem> CityList { get; set; }

        public CityListViewModel()
        {
            CityList = new List<CityListItem>
            {
                new CityListItem
                {
                    CityName = "Brisbane",
                    ImagePath = "brisbane.jpg"
                },
                new CityListItem
                {
                    CityName = "Melbourne",
                    ImagePath = "melbourne.jpg"
                },
                new CityListItem
                {
                    CityName = "Sydney",
                    ImagePath = "sydney.jpg"
                }

            };
        }
    }
}
