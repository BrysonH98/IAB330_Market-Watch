﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using mw_rest_api.Models;

namespace mw_rest_api.Services
{
    public class SomethingRepository
    {
        private const string CacheKey = "SomethingStore";

        public SomethingRepository()
        {
            var ctx = HttpContext.Current;

            if (ctx != null)
            {
                if (ctx.Cache[CacheKey] == null)
                {
                    var Somethings = new Something[]
                    {
                        new Something
                        {
                            Id=1, Name = "Glenn Block"
                        },
                        new Something
                        {
                            Id=2, Name="Dan Roth"
                        }
                    };

                    ctx.Cache[CacheKey] = Somethings;
                }
            }
        }

        public Something[] GetAllSomething()
        {
            var ctx = HttpContext.Current;

            if (ctx != null)
            {
                return (Something[])ctx.Cache[CacheKey];
            }

            return new Something[]
            {
                new Something
                {
                    Id=0, Name="Placeholder"
                }
            };
        }

        public bool SaveSomething(Something something)
        {
            var ctx = HttpContext.Current;

            if (ctx != null)
            {
                try
                {
                    var currentData = ((Something[])ctx.Cache[CacheKey]).ToList();
                    currentData.Add(something);
                    ctx.Cache[CacheKey] = currentData.ToArray();

                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    return false;
                }
            }

            return false;
        }
    }
}