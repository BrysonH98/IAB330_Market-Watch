﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using mw_rest_api.Services;
using mw_rest_api.Models;

namespace mw_rest_api.Controllers
{
    public class SomethingController : ApiController
    {
        private SomethingRepository contactRepository;

        public SomethingController()
        {
            this.contactRepository = new SomethingRepository();
        }

        public Something[] Get()
        {
            return this.contactRepository.GetAllSomething();
        }
    }
}
