﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Non_tabbed_Login
{
    public class Login_Result
    {
        public int customerID { get; set; }
        public string email { get; set; }
        public string cusPassword { get; set; }
        public int phone { get; set; }
    }
}
