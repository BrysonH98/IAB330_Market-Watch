﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Threading.Tasks;
using Refit;
using RestSharp;
using System.Net;
using RestSharp.Deserializers;

namespace Non_tabbed_Login
{
    public class Login_Method
    {
        public Login_Result Result { get; set; }
        public string Input_Email { get; set; }
        public string Input_Password { get; set; }

        public Login_Method( string inEmail, string inPass)
        {
            Input_Email = inEmail;
            Input_Password = inPass;
           
            var client = new RestClient("http://marketwatchapi.azurewebsites.net");
            var request = new RestRequest("/api/Customer/email='plop'/cusPassword='plop'", Method.GET);
            var response = client.Execute(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                string rawResponse = response.Content;
                Result = new JsonDeserializer().Deserialize<Login_Result>(response);
            }


        }


       

        
    }
}
