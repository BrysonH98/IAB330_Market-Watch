﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Non_tabbed_Login
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Login_Pressed(object sender, ItemTappedEventArgs e)
        {
            var GET_Inputs = new Login_Method(Email.Text,Password.Text);
            //Label_1.Text = GET_Inputs.Result.customerID.ToString();
            //Label_2.Text = GET_Inputs.Result.email;
            App.Current.MainPage = new NavigationPage(new Results_Page()
            {
                BindingContext = GET_Inputs
            });
        }
    }
}
